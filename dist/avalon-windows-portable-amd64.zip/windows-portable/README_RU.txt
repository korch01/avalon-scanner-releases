Портативная сборка Avalon Scanner (Windows amd64)
==================================================

Содержимое папки
-----------------
- AvalonScanner.exe — графическое приложение (Fyne). Подсистема Windows: GUI (без чёрного окна консоли).
- avalon-scan.exe   — консольный сканер сети.
- fmsc.exe          — CLI: upgrade, pools, led, reboot, workmode.
- miner-dump.exe    — отладочный дамп summary/pools/estats.

Требования на ПК с Windows
--------------------------
- 64-разрядная Windows 10/11 (amd64).
- Драйверы OpenGL / графическая подсистема (для окна Fyne обычно достаточно стандартных библиотек Windows).
- Разрешение в брандмауэре для сканирования LAN (при первом запуске Windows может спросить).

Запуск
------
- Двойной щелчок по AvalonScanner.exe или запуск из cmd/PowerShell.
- Консольный пример:
    avalon-scan.exe -cidr 192.168.1.0/24

Установка не требуется: можно держать всю папку на флешке или в одном каталоге.

Сборка с нуля (на Linux с MinGW)
--------------------------------
Из корня модуля fmsg:
    chmod +x scripts/build-windows-portable.sh
    ./scripts/build-windows-portable.sh

Появится также dist/avalon-windows-portable-amd64.zip при наличии команды zip.
